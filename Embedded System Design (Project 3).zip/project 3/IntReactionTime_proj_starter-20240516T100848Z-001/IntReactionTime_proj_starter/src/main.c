#include <platform.h>
#include <gpio.h>
#include <stdlib.h>
#include <stdio.h>
#include "leds.h"
#include "delay.h"
#include "lcd.h"

#define MEASUREMENT_COUNT 10

static volatile int done;

//for printing best score
static volatile unsigned __int64 best_score = 0;
static volatile int first_run = 1;
//for printing from which color best avg comes from
static unsigned __int64 red_scores[MEASUREMENT_COUNT];
static unsigned __int64 green_scores[MEASUREMENT_COUNT];
static unsigned __int64 yellow_scores[MEASUREMENT_COUNT];

void button_press_isr(int source) {
    done = 1;
}

//calculate avg
unsigned __int64 average_score(unsigned __int64 scores[], int count) {
    unsigned __int64 sum = 0;
    for (int i = 0; i < count; i++) {
        sum += scores[i];
    }
    return sum / count;
}

int main(void) {
    volatile unsigned __int64 count;
    volatile unsigned __int64 storedcnt;
    char buffer[20];
    char best_buffer[20];

    // Initialize LEDs and lcd.
    leds_init();
    lcd_init();    
    lcd_set_cursor(0, 0);
    lcd_print("best:");
    sprintf(best_buffer, "%llu", best_score);
    lcd_print(best_buffer);

    // Set up on-board switch.
    gpio_set_mode(P_SW, PullUp);
    gpio_set_trigger(P_SW, Rising);
    gpio_set_callback(P_SW, button_press_isr);

    // set up led pins
    gpio_set_mode(P_LED_R, Output);
    gpio_set_mode(P_LED_G, Output);
    gpio_set_mode(P_LED_B, Output);  //yellow not blue

    // Enable Global Interrupts
    __enable_irq();

    //for keeping track of readings
    int measurements = 0;
    int red_idx = 0, green_idx = 0, yellow_idx = 0;

    while (1) {
        //reset count val
        count = 0;
        //random wait
        delay_ms(rand() % 2000 + 1000); 

        //turn on one of the leds
        int random_led = rand() % 3; 
        switch (random_led) {
            case 0:
                gpio_set(P_LED_R, 1);
                break;
            case 1:
                gpio_set(P_LED_G, 1);
                break;
            case 2:
                gpio_set(P_LED_B, 1);
                break;
            default:
                break;
        }

        done = 0;
        while (!done) {
            count++;
        }
        //store count val
        storedcnt = count;

        //turn off leds
        gpio_set(P_LED_R, 0);
        gpio_set(P_LED_G, 0);
        gpio_set(P_LED_B, 0);
				
				
        if (first_run) {
            best_score = storedcnt;
            first_run = 0;
        } else if (storedcnt < best_score) {
            best_score = storedcnt;
        }

        //store current score in the appropriate array
        switch (random_led) {
            case 0:
                red_scores[red_idx++] = storedcnt;
                break;
            case 1:
                green_scores[green_idx++] = storedcnt;
                break;
            case 2:
                yellow_scores[yellow_idx++] = storedcnt;
                break;
        }

        //display count on lcd
        sprintf(buffer, "%llu", storedcnt);
        lcd_clear();
        lcd_set_cursor(0, 1);
        lcd_print("score:");
        lcd_print(buffer);

        //display best score
        lcd_set_cursor(0, 0);
        lcd_print("best:");
        sprintf(best_buffer, "%llu", best_score);
        lcd_print(best_buffer);

        measurements++;

        //after 10 measurements, calculate avgs, determine best avg score
        if (measurements == MEASUREMENT_COUNT) {
            unsigned __int64 avg_red = average_score(red_scores, red_idx);
            unsigned __int64 avg_green = average_score(green_scores, green_idx);
            unsigned __int64 avg_yellow = average_score(yellow_scores, yellow_idx);
            unsigned __int64 best_avg = avg_red;
            int best_color = 0; 
            if (avg_green < best_avg) {
                best_avg = avg_green;
                best_color = 1; 
            }
            if (avg_yellow < best_avg) {
                best_avg = avg_yellow;
                best_color = 2; 
            }

            //display best avg score and its color
            lcd_clear();
            lcd_set_cursor(0, 0);
            lcd_print("best avg:");
            sprintf(buffer, "%llu", best_avg);
            lcd_print(buffer);
            lcd_set_cursor(0, 1);
            lcd_print("color: ");
            if (best_color == 0) {
                lcd_print("red");
            } else if (best_color == 1) {
                lcd_print("green");
            } else {
                lcd_print("yellow");
            }

            //reset for next 10 readings
            measurements = 0;
            red_idx = 0;
            green_idx = 0;
            yellow_idx = 0;
        }

        //delay approx 5 seconds
        delay_ms(5000);
    }
}

//dr omar i also edited the lcd.c file to replace the wait_while_busy function with a short delay so that the lcd would print

// *******************************ARM University Program Copyright � ARM Ltd 2016*************************************   

