#ifndef SWITCHES_H
#define SWITCHES_H

void switches_init(void);
int switch_get(Pin pin);

#endif // SWITCHES_H

// *******************************ARM University Program Copyright � ARM Ltd 2016*************************************   
