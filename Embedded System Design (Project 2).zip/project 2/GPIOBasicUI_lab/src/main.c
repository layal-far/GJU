#include <platform.h>
#include <gpio.h>
#include "delay.h"
#include "lcd.h"
#include "switches.h"
#include "leds.h"

void print_switches() {
	lcd_set_cursor(0, 1);
	
	if (switch_get(P_SW_UP)) {
		lcd_print("  let u down     ");
	} else if (switch_get(P_SW_CR)) {
		lcd_print("  run around     ");
	} else if (switch_get(P_SW_DN)) {
		lcd_print("  desert u       ");
	} else if (switch_get(P_SW_LT)) {
		lcd_print("  make u cry     ");
	} else if (switch_get(P_SW_RT)) {
		lcd_print("  saay goodbyee  ");
	} else {
		lcd_print("  give u up      ");
	}
}

void light_leds() {
	leds_set(switch_get(P_SW_UP),
	         switch_get(P_SW_CR),
	         switch_get(P_SW_DN));
}

int main(void) {
	switches_init();
	leds_init();
	lcd_init();	
	lcd_print("  never gonna  ");
	
	while (1) {
		print_switches();
		light_leds();
	}
}

// *******************************ARM University Program Copyright � ARM Ltd 2016*************************************   
